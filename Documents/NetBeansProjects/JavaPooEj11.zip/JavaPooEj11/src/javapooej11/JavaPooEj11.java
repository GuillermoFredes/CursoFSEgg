/*
Pongamos de lado un momento el concepto de POO, ahora vamos a trabajar solo con la
clase Date. En este ejercicio deberemos instanciar en el main, una fecha usando la clase
Date, para esto vamos a tener que crear 3 variables, dia, mes y anio que se le pedirán al
usuario para poner el constructor del objeto Date. Una vez creada la fecha de tipo Date,
deberemos mostrarla y mostrar cuantos años hay entre esa fecha y la fecha actual, que se
puede conseguir instanciando un objeto Date con constructor vacío.
Ejemplo fecha: Date fecha = new Date(anio, mes, dia);
Ejemplo fecha actual: Date fechaActual = new Date();
 */
package javapooej11;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Scanner;

/**
 *
 * @author A308862
 */
public class JavaPooEj11 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  throws ParseException {
        
        int anio=0;
        int mes=0;
        int dia=0;
        
        
        Scanner scn = new Scanner(System.in).useDelimiter("\n");

        System.out.println("Ingrese año:");
        anio=scn.nextInt();
        
        System.out.println("Ingrese mes:");
        mes=scn.nextInt();
        
        System.out.println("Ingrese dia:");
        dia=scn.nextInt();
        
        LocalDate fechaActual = LocalDate.now();
        
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");

        Date fechaFinal = dateFormat.parse(""+fechaActual);
        Date fechaInicial = dateFormat.parse(""+anio+"-"+mes+"-"+dia+"");
        int dias = (int) ((fechaFinal.getTime() - fechaInicial.getTime()) / 86400000);
        
        System.out.println("Fecha Ingresada : " + fechaInicial);
        System.out.println("Fecha de Hoy    : " + fechaFinal);
        System.out.println("Hay " + dias + " dias de diferencia");
        
    }
    
}
